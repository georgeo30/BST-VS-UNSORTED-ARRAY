import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;


public class PowerArrayApp
{
    public static String[] csvSpecData;
    public static String toFile=new String();
    public static void main(String[] args)
    {
        String[] csvData= new String[500];
        try
        {
            Scanner csvFile =new Scanner(new File("cleaned_data.csv"));
            csvFile.nextLine();
            csvFile.useDelimiter("\n");
            while (csvFile.hasNext())
            {
                for (int i=0;i<500;i++)
                {
                    csvData[i]= csvFile.next();
                }
            }
            csvFile.close();
            
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        
        csvSpecData= new String[500];
        
        for (int i=0; i<500;i++)
        {
            String temp[]=csvData[i].split(",");
            csvSpecData[i]=temp[0]+","+temp[1]+","+temp[3];
        }
        if (args.length <1)
        {
            printAllDateTimes();
        }
        else
        {
            printDateTime(args[0]);
        }

       
    }
    
    public static void printDateTime(String dateTime)
    {   boolean found=false;
        int opCount =0;
        for (int i=0;i<500;i++)
        {   
            opCount++;
            String temp[]=csvSpecData[i].split(",");
            if (temp[0].equals(dateTime))
            {   
                System.out.println(csvSpecData[i]);
                found=true;
                break;
            }
            
        }
        
        toFile=opCount+"";
        if (found==false)
        {
            System.out.println("Date/time not found");
        }       
        writeToFile(toFile);
        
    }
    public static void writeToFile(String toFile)
    {
        try
        {
            FileWriter fileWriter = new FileWriter("part2test.txt",true);
            fileWriter.write(toFile+"\n");
            fileWriter.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    public static void printAllDateTimes()
    {
        for (int i=0;i<500;i++)
        {
            System.out.println(csvSpecData[i]);
        }
    }
    
    public static void testing()
    {
       
        for (int i=0;i<500;i++)
        {
            String temp[]=csvSpecData[i].split(",");
            printDateTime(temp[0]);
            
            
        }
    }
}
