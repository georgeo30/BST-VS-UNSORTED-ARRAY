/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Geo
 */

//importing files
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;

public class PowerBSTApp
{   
	//public static String[] list= new String[500];
	 public static String toFile=new String();
        public static BinarySearchTree x=new BinarySearchTree();
    public static void main(String[] args)
    {try                                                                 /**trycatch block*/
        {                               
            Scanner csvFile =new Scanner(new File("cleaned_data.csv"));     //reading csv file
            csvFile.nextLine();                                             //skipping first line
            csvFile.useDelimiter("\n");                                     //split at end of 8 columns
            while(csvFile.hasNext())                                        //while loop until it points to null
            {   
		        
                String[] temp=csvFile.nextLine().split(",");                //splitting each line into a temporary storage
                x.insert(temp[0]+","+temp[1]+","+temp[3]);                  //inserting into the binary search tree  
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());                             //catch block error message
        }
        if (args.length <1)
        {
            x.inOrder(x.root);                                              //calling printALL method 
        }
        else
        {
            
            BinarySearchTree.Node k =x.search(x.root,args[0]);              //a new variable called k is created of type Node
            if (k==null)                                                    //k is given calue null is date.time is not found
            {
                System.out.println("Date/time not found");
            }
            else
            {
                toFile="FOr date: "+args[0]+" searched through: "+x.opCount+" times";             //opCount is accesed from BinarySearchFile
                System.out.println(k.key);                                  //coresponding volatge and power is output
                writeToFile(toFile);                                        //written to a file
            }
        }
	
  }  
    public static void writeToFile(String toFile)
    {
        try
        {
            FileWriter fileWriter = new FileWriter("part4test.txt",true);        //writing to a file called part4test.txt
            fileWriter.write( toFile +"\n");
            fileWriter.close();
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    
    public static void testing()
    {
    try                                                                 
        {                              
            Scanner csvFile =new Scanner(new File("cleaned_data.csv"));    
            csvFile.nextLine();                                             
            csvFile.useDelimiter("\n");                       
            while(csvFile.hasNext())                                       
            {           
                String[] temp=csvFile.nextLine().split(",");                
                BinarySearchTree.Node k =x.search(x.root,temp[0]);
                writeToFile(x.opCount+"");
                x.setCtoZero();
                                
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());                            
        }
	
    }
    
}
