/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Geo
 */
public class BinarySearchTree
{
    /*class that contains left and right child*/
    public class Node
    {
        public String key;
        public Node left, right;
        
        public Node(String item)
        {
            key=item;
            left=right=null;
        }
    }
    
    //root of bst
    public Node root;
    public int opCount=0;
    
    public BinarySearchTree()
    {
        root=null;
    }
    
    public void insert(String key)
    {
        root=insertRec(root,key);
    }
    //Recurive function to insert new key in BST
    public Node insertRec(Node root,String key)
    {
        //checks if tree is empty and if so then returns a new node
        if (root==null)
        {
            root =new Node(key);
            return root;
        }
        // recurse down the treeotherwise
        int x=key.compareTo(root.key);
        if (x<0)
        {
            root.left=insertRec(root.left,key);
            
        }
        
        else if(x>0)
        {
            root.right=insertRec(root.right,key);
        }
        
            
        return root;
        
    }
    
    //searching the bst file
    public Node search(Node root, String key)
    {   
        //recursive
        //base case
        
        if (root==null)
        {return null;}
        int x =key.compareTo(root.key.split(",")[0]);
        
        {
        if (root==null || x==0)
        {
            this.opCount++;
            return root;
        }
        
        //if the value is gretaer than the root key
        if (x<0)
        {
            this.opCount++;
            return search(root.left,key);
        }
        //if left side is bigger
     
            this.opCount++;
            return search(root.right,key);
            
        
        
        }
        
    }
    public void inOrder(Node root)
    {
        if (root==null)
        {     }
        else
        {   
            inOrder(root.left);
            System.out.println(root.key);
            inOrder(root.right);
            
        }
        
    }
    
    public int counter()
    {
        return this.opCount;
        
    }
    public void setCtoZero()
    
    {
        this.opCount=0;
    }
}
